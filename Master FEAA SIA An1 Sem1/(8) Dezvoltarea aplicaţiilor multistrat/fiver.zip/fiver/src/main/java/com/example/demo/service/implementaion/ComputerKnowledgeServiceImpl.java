package com.example.demo.service.implementaion;

import com.example.demo.dao. ComputerKnowledgeDao;
import com.example.demo.entities. ComputerKnowledge;
import com.example.demo.service.ComputerKnowledgeService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ComputerKnowledgeServiceImpl implements ComputerKnowledgeService {
    private  final com.example.demo.dao. ComputerKnowledgeDao  ComputerKnowledgeDao;

    public   ComputerKnowledgeServiceImpl(  ComputerKnowledgeDao   ComputerKnowledgeDao) {
        this.  ComputerKnowledgeDao =   ComputerKnowledgeDao;
    }

    @Override
    public List< ComputerKnowledge> findAll() {
        return   ComputerKnowledgeDao.findAll();
    }

    @Override
    public Optional<  ComputerKnowledge> findById(Long id) {
        return   ComputerKnowledgeDao.findById(id);
    }

    @Override
    public   ComputerKnowledge save(  ComputerKnowledge   ComputerKnowledge) {
        return   ComputerKnowledgeDao.save(  ComputerKnowledge);
    }

    @Override
    public void deleteById(Long id) {
         ComputerKnowledgeDao.delete(id);
    }
}
