package com.example.demo.enums;

public enum Software {
    Office,Word, PowerPoint, Outlook,Excel,Slack;
}
