package com.example.demo.controllers;

import com.example.demo.dto.ComputerKnowledgeDto;
import com.example.demo.mappers.ComputerKnowledgeMapper;
import com.example.demo.service.ComputerKnowledgeService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
 import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("computerKnowledges")
public class ComputerKnowledgeController {


    private final  ComputerKnowledgeService ComputerKnowledgeService;
    private final  ComputerKnowledgeMapper ComputerKnowledgeMapper;
    private final ComputerKnowledgeDto ComputerKnowledgeDTO;

    public ComputerKnowledgeController(ComputerKnowledgeDto ComputerKnowledgeDTO, ComputerKnowledgeService ComputerKnowledgeService, ComputerKnowledgeMapper ComputerKnowledgeMapper) {
        this.ComputerKnowledgeDTO = ComputerKnowledgeDTO;
        this.ComputerKnowledgeService = ComputerKnowledgeService;
        this.ComputerKnowledgeMapper = ComputerKnowledgeMapper;
    }


    @GetMapping
    public ResponseEntity<List<ComputerKnowledgeDto>> getAllComputerKnowledges() {
        return ResponseEntity.ok(ComputerKnowledgeMapper.convertToDtos(ComputerKnowledgeService.findAll()));
    }

    @Operation(description = "Add new   ComputerKnowledge")
    @ApiResponses(value = {@ApiResponse(responseCode = "201", description = "  ComputerKnowledge aded",
            content = @Content),
            @ApiResponse(responseCode = "400", description = "Invalid   ComputerKnowledge    data",
                    content = @Content),
            @ApiResponse(responseCode = "500", description = "Business exception",
                    content = @Content)})

    @PostMapping
    public ResponseEntity<ComputerKnowledgeDto> addComputerKnowledge(@RequestBody ComputerKnowledgeDto ComputerKnowledgeDto) {
        ComputerKnowledgeService.save(ComputerKnowledgeMapper.convertToEntity(ComputerKnowledgeDto));
        return ResponseEntity.status(HttpStatus.CREATED).body(ComputerKnowledgeDto);

    }

    @Operation(description = "Delete a   ComputerKnowledge")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "204", description = "  ComputerKnowledge deleted",
                    content = @Content),
            @ApiResponse(responseCode = "404", description = "  ComputerKnowledge not found to update",
                    content = @Content)})

    @DeleteMapping("{id ComputerKnowledge}")
    public void cancelTrip(@PathVariable Long idComputerKnowledge) {
        this.ComputerKnowledgeService.deleteById(idComputerKnowledge);

    }
}