package com.example.demo.mappers;

import com.example.demo.dto.EducationDto;
import com.example.demo.entities.Education;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

import java.util.List;

@Component

public class EducationMapper {
    private final ModelMapper modelMapper;

    public EducationMapper(ModelMapper modelMapper) {
        this.modelMapper = modelMapper;
    }

    public EducationDto convertToDto(Education Education) {
        return modelMapper.map(Education, EducationDto.class);
    }
    public List<EducationDto> convertToDtos(List<Education> cars) {
        return modelMapper.map(cars, List.class);
    }
    public Education convertToEntity(EducationDto dto) {
        return modelMapper.map(dto, Education.class);
    }
    public Education convertToNewEntity(EducationDto EducationDto) {
        Education  Education =  modelMapper.map(EducationDto, Education.class);

        return Education;
    }

}
