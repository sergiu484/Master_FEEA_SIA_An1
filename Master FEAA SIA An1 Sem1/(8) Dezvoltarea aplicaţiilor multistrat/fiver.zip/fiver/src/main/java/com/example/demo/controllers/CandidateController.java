package com.example.demo.controllers;

import com.example.demo.dto. CandidateDto;
import com.example.demo.mappers. CandidateMapper;
import com.example.demo.service. CandidateService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("candidates")
public class CandidateController {
    @Autowired
    private final  CandidateService  CandidateService;
    private final  CandidateMapper  CandidateMapper;
    private final  CandidateDto  CandidateDTO;

    public  CandidateController( CandidateDto  CandidateDTO,  CandidateService  CandidateService,  CandidateMapper  CandidateMapper) {
        this. CandidateDTO =  CandidateDTO;
        this. CandidateService =  CandidateService;
        this. CandidateMapper =  CandidateMapper;
    }


    @GetMapping
    public ResponseEntity<List<CandidateDto>> getAllCandidates(){
        return ResponseEntity.ok(  CandidateMapper.convertToDtos(  CandidateService.findAll()));
    }

    @Operation(description = "Add new   Candidate")
    @ApiResponses(value = {     @ApiResponse(responseCode = "201", description = "  Candidate aded",
            content = @Content),
            @ApiResponse(responseCode = "400", description = "Invalid   Candidate    data",
                    content = @Content),
            @ApiResponse(responseCode = "500", description = "Business exception",
                    content = @Content)})

    @PostMapping
    public ResponseEntity<  CandidateDto>  addCandidate(@RequestBody  CandidateDto   CandidateDto) {
         CandidateService.save( CandidateMapper.convertToEntity(  CandidateDto));
        return ResponseEntity.status(HttpStatus.CREATED).body(  CandidateDto);

    }
    @Operation(description = "Delete a   Candidate")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "204", description = "  Candidate deleted",
                    content = @Content),
            @ApiResponse(responseCode = "404", description = "  Candidate not found to update",
                    content = @Content)})

    @DeleteMapping("{id Candidate}")
    public void cancelTrip(@PathVariable Long idCandidate) {
        this. CandidateService.deleteById(idCandidate);

    }
}
