package com.example.demo.dao;
import com.example.demo.entities.ComputerKnowledge;
import com.example.demo.entities.Diploma;
import com.example.demo.repositories.ComputerKnowledgeRepository;
import com.example.demo.repositories.DiplomaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class DiplomaDao {

    private final DiplomaRepository diplomaRepository;



    public DiplomaDao(DiplomaRepository diplomaRepository) {
        this.diplomaRepository = diplomaRepository;
    }

    public List<Diploma> findAll() {

        return diplomaRepository.findAll();
    }

    public Optional<Diploma> findById(Long id) {

        return diplomaRepository.findById(id);
    }

    public Diploma save (Diploma diploma) {

        return diplomaRepository.save(diploma);

    }


    public void delete(Long id) {

        diplomaRepository.delete(diplomaRepository.getOne(id));
    }

}
