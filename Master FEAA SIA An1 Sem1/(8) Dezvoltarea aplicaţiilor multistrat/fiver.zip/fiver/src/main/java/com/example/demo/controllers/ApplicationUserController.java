package com.example.demo.controllers;

import com.example.demo.dao.ApplicationUserDao;
import com.example.demo.dto.ApplicationUserDto;
import com.example.demo.mappers.ApplicationUserMapper;
import com.example.demo.service.ApplicationUserService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


import java.util.List;

@RestController
@RequestMapping("users")
public class ApplicationUserController {
@Autowired
    private final ApplicationUserService applicationUserService;
    private final ApplicationUserMapper applicationUserMapper;
    private final ApplicationUserDto applicationUserDTO;

    public ApplicationUserController(ApplicationUserDto applicationUserDTO, ApplicationUserService applicationUserService, ApplicationUserMapper applicationUserMapper) {
        this.applicationUserDTO = applicationUserDTO;
        this.applicationUserService = applicationUserService;
        this.applicationUserMapper = applicationUserMapper;
    }


    @GetMapping
    public ResponseEntity<List< ApplicationUserDto>> getAllApplicationUsers(){
        return ResponseEntity.ok( applicationUserMapper.convertToDtos( applicationUserService.findAll()));
    }

    @Operation(description = "Add new  ApplicationUser")
    @ApiResponses(value = {     @ApiResponse(responseCode = "201", description = " ApplicationUser aded",
                    content = @Content),
            @ApiResponse(responseCode = "400", description = "Invalid  ApplicationUser    data",
                    content = @Content),
            @ApiResponse(responseCode = "500", description = "Business exception",
                    content = @Content)})

    @PostMapping
    public ResponseEntity< ApplicationUserDto>  addApplicationUser(@RequestBody  ApplicationUserDto  ApplicationUserDto) {
         applicationUserService.save( applicationUserMapper.convertToEntity( ApplicationUserDto));
        return ResponseEntity.status(HttpStatus.CREATED).body( ApplicationUserDto);

    }
    @Operation(description = "Delete a  ApplicationUser")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "204", description = " ApplicationUser deleted",
                    content = @Content),
            @ApiResponse(responseCode = "404", description = " ApplicationUser not found to update",
                    content = @Content)})

    @DeleteMapping("{idApplicationUser}")
    public void cancelTrip(@PathVariable Long idApplicationUser) {
        this.applicationUserService.deleteById(idApplicationUser);

    }}
