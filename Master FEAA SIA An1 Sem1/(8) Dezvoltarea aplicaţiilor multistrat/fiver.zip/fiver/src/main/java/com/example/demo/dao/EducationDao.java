package com.example.demo.dao;

import com.example.demo.entities.Diploma;
import com.example.demo.entities.Education;
import com.example.demo.repositories.DiplomaRepository;
import com.example.demo.repositories.EducationRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class EducationDao {
    private final EducationRepository educationRepository;


    public EducationDao(EducationRepository educationRepository) {
        this.educationRepository = educationRepository;
    }

    public List<Education> findAll() {

        return educationRepository.findAll();
    }

    public Optional<Education> findById(Long id) {

        return educationRepository.findById(id);
    }

    public Education save(Education education) {

        return educationRepository.save(education);

    }


    public void delete(Long id) {

        educationRepository.delete(educationRepository.getOne(id));
    }
}
