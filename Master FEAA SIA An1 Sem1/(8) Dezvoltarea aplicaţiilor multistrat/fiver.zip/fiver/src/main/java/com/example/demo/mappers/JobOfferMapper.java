package com.example.demo.mappers;

import com.example.demo.dto.JobOfferDto;
import com.example.demo.entities.JobOffer;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

import java.util.List;

@Component

public class JobOfferMapper {
    private final ModelMapper modelMapper;

    public JobOfferMapper(ModelMapper modelMapper) {
        this.modelMapper = modelMapper;
    }

    public JobOfferDto convertToDto(JobOffer JobOffer) {
        return modelMapper.map(JobOffer, JobOfferDto.class);
    }
    public List<JobOfferDto> convertToDtos(List<JobOffer> cars) {
        return modelMapper.map(cars, List.class);
    }
    public JobOffer convertToEntity(JobOfferDto dto) {
        return modelMapper.map(dto, JobOffer.class);
    }
    public JobOffer convertToNewEntity(JobOfferDto JobOfferDto) {
        JobOffer  JobOffer =  modelMapper.map(JobOfferDto, JobOffer.class);

        return JobOffer;
    }

}
