package com.example.demo.mappers;

import com.example.demo.dto.RecruiterDto;
import com.example.demo.entities.Recruiter;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

import java.util.List;

@Component

public class RecruiterMapper {
    private final ModelMapper modelMapper;


    public RecruiterMapper(ModelMapper modelMapper) {
        this.modelMapper = modelMapper;
    }

    public RecruiterDto convertToDto(Recruiter recruiter) {
        return modelMapper.map(recruiter, RecruiterDto.class);
    }
    public List<RecruiterDto> convertToDtos(List<Recruiter> cars) {
        return modelMapper.map(cars, List.class);
    }
    public Recruiter convertToEntity(RecruiterDto dto) {
        return modelMapper.map(dto, Recruiter.class);
    }
    public Recruiter convertToNewEntity(RecruiterDto recruiterDto) {
        Recruiter  recruiter =  modelMapper.map(recruiterDto, Recruiter.class);

        return recruiter;
    }





}
