package com.example.demo.service.implementaion;

import com.example.demo.dao. RecruiterDao;
import com.example.demo.entities. Recruiter;
import com.example.demo.service.RecruiterService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class RecruiterServiceImpl implements RecruiterService {
    private  final  RecruiterDao  RecruiterDao;

    public  RecruiterServiceImpl( RecruiterDao  RecruiterDao) {
        this. RecruiterDao =  RecruiterDao;
    }

    @Override
    public List< Recruiter> findAll() {
        return  RecruiterDao.findAll();
    }

    @Override
    public Optional< Recruiter> findById(Long id) {
        return  RecruiterDao.findById(id);
    }

    @Override
    public  Recruiter save( Recruiter  Recruiter) {
        return  RecruiterDao.save( Recruiter);
    }

    @Override
    public void deleteById(Long id) {
         RecruiterDao.delete(id);
    }
}
