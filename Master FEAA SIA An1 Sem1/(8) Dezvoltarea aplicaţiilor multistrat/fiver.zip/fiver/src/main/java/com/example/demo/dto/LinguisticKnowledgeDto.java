package com.example.demo.dto;

import com.example.demo.enums.Language;
import com.example.demo.enums.LevelLanguage;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Enumerated;
import javax.persistence.ManyToMany;
import java.io.Serializable;
@Data
@AllArgsConstructor
@NoArgsConstructor

public class LinguisticKnowledgeDto implements Serializable {
    private static final long serialVersionUID = 1L;
    private Long id;
     private Language language;
     private LevelLanguage levelLanguage;

}
