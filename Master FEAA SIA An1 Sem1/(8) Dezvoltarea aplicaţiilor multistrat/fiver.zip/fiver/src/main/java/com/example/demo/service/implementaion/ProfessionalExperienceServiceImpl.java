package com.example.demo.service.implementaion;

import com.example.demo.dao.LinguisticKnowledgeDao;
import com.example.demo.dao.ProfessionalExperienceDao;
import com.example.demo.entities.LinguisticKnowledge;
import com.example.demo.entities.ProfessionalExperience;
import com.example.demo.service.ProfessionalExperienceService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProfessionalExperienceServiceImpl implements ProfessionalExperienceService {
    private  final com.example.demo.dao.ProfessionalExperienceDao ProfessionalExperienceDao;


    public   ProfessionalExperienceServiceImpl(  ProfessionalExperienceDao   ProfessionalExperienceDao) {
        this.  ProfessionalExperienceDao =   ProfessionalExperienceDao;
    }

    @Override
    public List<ProfessionalExperience> findAll() {
        return   ProfessionalExperienceDao.findAll();
    }

    @Override
    public Optional<  ProfessionalExperience> findById(Long id) {
        return   ProfessionalExperienceDao.findById(id);
    }

    @Override
    public   ProfessionalExperience save(  ProfessionalExperience   ProfessionalExperience) {
        return   ProfessionalExperienceDao.save(  ProfessionalExperience);
    }

    @Override
    public void deleteById(Long id) {
        ProfessionalExperienceDao.delete(id);
    }
}
