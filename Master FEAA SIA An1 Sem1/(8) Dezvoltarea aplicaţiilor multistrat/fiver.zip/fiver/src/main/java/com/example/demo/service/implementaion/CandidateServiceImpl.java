package com.example.demo.service.implementaion;


import com.example.demo.dao. CandidateDao;
import com.example.demo.entities. Candidate;
import com.example.demo.service.CandidateService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CandidateServiceImpl implements CandidateService {
    private  final  CandidateDao  CandidateDao;

    public  CandidateServiceImpl( CandidateDao  CandidateDao) {
        this. CandidateDao =  CandidateDao;
    }

    @Override
    public List< Candidate> findAll() {
        return  CandidateDao.findAll();
    }

    @Override
    public Optional< Candidate> findById(Long id) {
        return  CandidateDao.findById(id);
    }

    @Override
    public  Candidate save( Candidate  Candidate) {
        return  CandidateDao.save( Candidate);
    }

    @Override
    public void deleteById(Long id) {
         CandidateDao.delete(id);
    }
}
