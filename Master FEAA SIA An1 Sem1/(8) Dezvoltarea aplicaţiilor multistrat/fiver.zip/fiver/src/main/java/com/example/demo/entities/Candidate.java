package com.example.demo.entities;

import com.example.demo.enums.CandidateType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.Date;
import java.util.List;


@Entity
@Inheritance(strategy = InheritanceType.JOINED)
@Data @AllArgsConstructor @NoArgsConstructor
@PrimaryKeyJoinColumn(name = "id")

public class Candidate extends ApplicationUser{
private String adress;
private Date date;
    @Enumerated
private CandidateType candidateType;
@ManyToMany
private List<JobOffer> jobOffers;
@ManyToMany
    private List<JobRequest > jobRequests;
}
