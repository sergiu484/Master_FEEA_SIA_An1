package com.example.demo.service.implementaion;

import com.example.demo.dao.ComputerKnowledgeDao;
import com.example.demo.entities.ComputerKnowledge;
import com.example.demo.entities.Diploma;
import com.example.demo.service.DiplomaService;
import org.springframework.stereotype.Service;

import java.net.DatagramSocketImplFactory;
import java.util.List;
import java.util.Optional;

@Service
public class DiplomaServiceImpl implements DiplomaService {
    private  final com.example.demo.dao. DiplomaDao  DiplomaDao;

    public   DiplomaServiceImpl(  com.example.demo.dao.DiplomaDao DiplomaDao) {
        this.  DiplomaDao =   DiplomaDao;
    }

    @Override
    public List<Diploma> findAll() {
        return   DiplomaDao.findAll();
    }

    @Override
    public Optional<  Diploma> findById(Long id) {
        return   DiplomaDao.findById(id);
    }

    @Override
    public   Diploma save(  Diploma   Diploma) {
        return   DiplomaDao.save(  Diploma);
    }

    @Override
    public void deleteById(Long id) {
        DiplomaDao.delete(id);
    }
}
