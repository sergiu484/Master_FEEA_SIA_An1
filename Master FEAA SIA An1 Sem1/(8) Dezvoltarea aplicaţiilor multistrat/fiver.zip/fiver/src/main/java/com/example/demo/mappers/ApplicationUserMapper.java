package com.example.demo.mappers;

import com.example.demo.dto.ApplicationUserDto;
import com.example.demo.entities.ApplicationUser;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

import java.util.List;
@Component

public class ApplicationUserMapper {
    private final ModelMapper modelMapper;

    public ApplicationUserMapper(ModelMapper modelMapper) {
        this.modelMapper = modelMapper;
    }

    public ApplicationUserDto convertToDto(ApplicationUser ApplicationUser) {
        return modelMapper.map(ApplicationUser, ApplicationUserDto.class);
    }
    public List<ApplicationUserDto> convertToDtos(List<ApplicationUser> cars) {
        return modelMapper.map(cars, List.class);
    }
    public ApplicationUser convertToEntity(ApplicationUserDto dto) {
        return modelMapper.map(dto, ApplicationUser.class);
    }
    public ApplicationUser convertToNewEntity(ApplicationUserDto ApplicationUserDto) {
        ApplicationUser  ApplicationUser =  modelMapper.map(ApplicationUserDto, ApplicationUser.class);

        return ApplicationUser;
    }

}
