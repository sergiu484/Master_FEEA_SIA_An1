package com.example.demo.controllers;

import com.example.demo.dto.JobRequestDto;
import com.example.demo.mappers.JobRequestMappper;
import com.example.demo.service.JobRequestService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("jobRequests")
public class JobRequestController {
    private final  JobRequestService JobRequestService;
    private final JobRequestMappper JobRequestMapper;
    private final JobRequestDto JobRequestDTO;

    public JobRequestController(JobRequestDto JobRequestDTO, JobRequestService JobRequestService, JobRequestMappper JobRequestMapper) {
        this.JobRequestDTO = JobRequestDTO;
        this.JobRequestService = JobRequestService;
        this.JobRequestMapper = JobRequestMapper;
    }


    @GetMapping
    public ResponseEntity<List<JobRequestDto>> getAllJobRequests() {
        return ResponseEntity.ok(JobRequestMapper.convertToDtos(JobRequestService.findAll()));
    }

    @Operation(description = "Add new   JobRequest")
    @ApiResponses(value = {@ApiResponse(responseCode = "201", description = "  JobRequest aded",
            content = @Content),
            @ApiResponse(responseCode = "400", description = "Invalid   JobRequest    data",
                    content = @Content),
            @ApiResponse(responseCode = "500", description = "Business exception",
                    content = @Content)})

    @PostMapping
    public ResponseEntity<JobRequestDto> addJobRequest(@RequestBody JobRequestDto JobRequestDto) {
        JobRequestService.save(JobRequestMapper.convertToEntity(JobRequestDto));
        return ResponseEntity.status(HttpStatus.CREATED).body(JobRequestDto);

    }

    @Operation(description = "Delete a   JobRequest")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "204", description = "  JobRequest deleted",
                    content = @Content),
            @ApiResponse(responseCode = "404", description = "  JobRequest not found to update",
                    content = @Content)})

    @DeleteMapping("{id JobRequest}")
    public void cancelTrip(@PathVariable Long idJobRequest) {
        this.JobRequestService.deleteById(idJobRequest);

    }
}
