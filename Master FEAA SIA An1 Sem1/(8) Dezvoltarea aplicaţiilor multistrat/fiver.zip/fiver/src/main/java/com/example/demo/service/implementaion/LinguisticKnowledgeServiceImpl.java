package com.example.demo.service.implementaion;

import com.example.demo.dao. LinguisticKnowledgeDao;
import com.example.demo.entities. LinguisticKnowledge;
import com.example.demo.service.LinguisticKnowledgeService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class LinguisticKnowledgeServiceImpl implements LinguisticKnowledgeService {
    private  final   LinguisticKnowledgeDao  LinguisticKnowledgeDao;


    public   LinguisticKnowledgeServiceImpl(  LinguisticKnowledgeDao   LinguisticKnowledgeDao) {
        this.  LinguisticKnowledgeDao =   LinguisticKnowledgeDao;
    }

    @Override
    public List< LinguisticKnowledge> findAll() {
        return   LinguisticKnowledgeDao.findAll();
    }

    @Override
    public Optional<  LinguisticKnowledge> findById(Long id) {
        return   LinguisticKnowledgeDao.findById(id);
    }

    @Override
    public   LinguisticKnowledge save(  LinguisticKnowledge   LinguisticKnowledge) {
        return   LinguisticKnowledgeDao.save(  LinguisticKnowledge);
    }

    @Override
    public void deleteById(Long id) {
         LinguisticKnowledgeDao.delete(id);
    }
}
