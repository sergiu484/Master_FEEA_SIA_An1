package com.example.demo.service;

import com.example.demo.entities.JobOffer;

import java.util.List;
import java.util.Optional;

public interface JobOfferService {
    public List<JobOffer> findAll();
    public Optional<JobOffer> findById(Long id);
    public JobOffer save(JobOffer JobOffer);
    public void deleteById(Long id);
}
