package com.example.demo.mappers;

import com.example.demo.dto.JobRequestDto;
import com.example.demo.entities.JobRequest;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

import java.util.List;

@Component

public class JobRequestMappper {
    private final ModelMapper modelMapper;

    public JobRequestMappper(ModelMapper modelMapper) {
        this.modelMapper = modelMapper;
    }

    public JobRequestDto convertToDto(JobRequest JobRequest) {
        return modelMapper.map(JobRequest, JobRequestDto.class);
    }
    public List<JobRequestDto> convertToDtos(List<JobRequest> cars) {
        return modelMapper.map(cars, List.class);
    }
    public JobRequest convertToEntity(JobRequestDto dto) {
        return modelMapper.map(dto, JobRequest.class);
    }
    public JobRequest convertToNewEntity(JobRequestDto JobRequestDto) {
        JobRequest  JobRequest =  modelMapper.map(JobRequestDto, JobRequest.class);

        return JobRequest;
    }

}
