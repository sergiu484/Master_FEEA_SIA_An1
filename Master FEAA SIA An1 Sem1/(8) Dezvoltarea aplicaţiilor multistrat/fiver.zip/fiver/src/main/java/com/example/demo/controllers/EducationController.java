package com.example.demo.controllers;

import com.example.demo.dto.EducationDto;
import com.example.demo.mappers.EducationMapper;
import com.example.demo.service.EducationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("educations")
public class EducationController {
    private final  EducationService EducationService;
    private final  EducationMapper EducationMapper;
    private final EducationDto EducationDTO;

    public EducationController(EducationDto EducationDTO, EducationService EducationService, EducationMapper EducationMapper) {
        this.EducationDTO = EducationDTO;
        this.EducationService = EducationService;
        this.EducationMapper = EducationMapper;
    }


    @GetMapping
    public ResponseEntity<List<EducationDto>> getAllEducations() {
        return ResponseEntity.ok(EducationMapper.convertToDtos(EducationService.findAll()));
    }

    @Operation(description = "Add new   Education")
    @ApiResponses(value = {@ApiResponse(responseCode = "201", description = "  Education aded",
            content = @Content),
            @ApiResponse(responseCode = "400", description = "Invalid   Education    data",
                    content = @Content),
            @ApiResponse(responseCode = "500", description = "Business exception",
                    content = @Content)})

    @PostMapping
    public ResponseEntity<EducationDto> addEducation(@RequestBody EducationDto EducationDto) {
        EducationService.save(EducationMapper.convertToEntity(EducationDto));
        return ResponseEntity.status(HttpStatus.CREATED).body(EducationDto);

    }

    @Operation(description = "Delete a   Education")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "204", description = "  Education deleted",
                    content = @Content),
            @ApiResponse(responseCode = "404", description = "  Education not found to update",
                    content = @Content)})

    @DeleteMapping("{id Education}")
    public void cancelTrip(@PathVariable Long idEducation) {
        this.EducationService.deleteById(idEducation);

    }
}
