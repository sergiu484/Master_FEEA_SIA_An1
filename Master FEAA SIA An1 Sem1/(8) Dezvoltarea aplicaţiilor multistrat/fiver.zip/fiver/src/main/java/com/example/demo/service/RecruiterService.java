package com.example.demo.service;

import com.example.demo.entities.Recruiter;

import java.util.List;
import java.util.Optional;

public interface RecruiterService {
    public List<Recruiter> findAll();
    public Optional<Recruiter> findById(Long id);
    public Recruiter save(Recruiter Recruiter);
    public void deleteById(Long id);
}
