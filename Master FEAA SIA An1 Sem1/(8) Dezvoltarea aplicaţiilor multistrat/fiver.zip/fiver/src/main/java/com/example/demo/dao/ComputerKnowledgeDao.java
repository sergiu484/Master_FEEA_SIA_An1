package com.example.demo.dao;
import com.example.demo.entities.ComputerKnowledge;
import com.example.demo.repositories.ComputerKnowledgeRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class ComputerKnowledgeDao {

    private final ComputerKnowledgeRepository computerKnowledgeRepository;



    public ComputerKnowledgeDao(ComputerKnowledgeRepository computerKnowledgeRepository) {
        this.computerKnowledgeRepository = computerKnowledgeRepository;
    }

    public List<ComputerKnowledge> findAll() {

        return computerKnowledgeRepository.findAll();
    }

    public Optional<ComputerKnowledge> findById(Long id) {

        return computerKnowledgeRepository.findById(id);
    }

    public ComputerKnowledge save (ComputerKnowledge computerKnowledge) {

        return computerKnowledgeRepository.save(computerKnowledge);

    }


    public void delete(Long id) {

        computerKnowledgeRepository.delete(computerKnowledgeRepository.getOne(id));
    }

}
