package com.example.demo.enums;

public enum LevelLanguage{
    Fluent,proficient,advanced,intermediate,conversational,competent,professional,elementary,beginner,basic;

}
