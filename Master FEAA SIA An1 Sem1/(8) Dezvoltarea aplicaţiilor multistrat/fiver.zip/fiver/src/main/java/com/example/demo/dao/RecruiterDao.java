package com.example.demo.dao;

import com.example.demo.entities.Recruiter;
import com.example.demo.repositories.RecruiterRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository


public class RecruiterDao {
    private final RecruiterRepository recruiterRepository;


    public RecruiterDao(RecruiterRepository recruiterRepository) {
        this.recruiterRepository = recruiterRepository;
    }

    public List<Recruiter> findAll() {

        return recruiterRepository.findAll();
    }

    public Optional<Recruiter> findById(Long id) {

        return recruiterRepository.findById(id);
    }

    public Recruiter save(Recruiter recruiter) {

        return recruiterRepository.save(recruiter);

    }


    public void delete(Long id) {

        recruiterRepository.delete(recruiterRepository.getOne(id));
    }
}
