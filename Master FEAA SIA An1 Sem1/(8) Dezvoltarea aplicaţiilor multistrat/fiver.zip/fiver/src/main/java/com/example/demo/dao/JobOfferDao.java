package com.example.demo.dao;
import com.example.demo.entities.JobOffer;
import com.example.demo.repositories.JobOfferRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class JobOfferDao {
    private final JobOfferRepository jobOfferRepository;


    public JobOfferDao(JobOfferRepository jobOfferRepository) {
        this.jobOfferRepository = jobOfferRepository;
    }

    public List<JobOffer> findAll() {

        return jobOfferRepository.findAll();
    }

    public Optional<JobOffer> findById(Long id) {

        return jobOfferRepository.findById(id);
    }

    public JobOffer save(JobOffer jobOffer) {

        return jobOfferRepository.save(jobOffer);

    }


    public void delete(Long id) {

        jobOfferRepository.delete(jobOfferRepository.getOne(id));
    }
}
