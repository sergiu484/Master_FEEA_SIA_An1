package com.example.demo.service;

import com.example.demo.entities.LinguisticKnowledge;

import java.util.List;
import java.util.Optional;

public interface LinguisticKnowledgeService {
    public List<LinguisticKnowledge> findAll();
    public Optional<LinguisticKnowledge> findById(Long id);
    public LinguisticKnowledge save(LinguisticKnowledge LinguisticKnowledge);
    public void deleteById(Long id);
}
