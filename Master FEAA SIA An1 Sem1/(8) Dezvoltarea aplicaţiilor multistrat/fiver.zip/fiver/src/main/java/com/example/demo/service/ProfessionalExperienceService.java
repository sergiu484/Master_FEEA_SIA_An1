package com.example.demo.service;

import com.example.demo.entities.ProfessionalExperience;

import java.util.List;
import java.util.Optional;

public interface ProfessionalExperienceService {
    public List<ProfessionalExperience> findAll();
    public Optional<ProfessionalExperience> findById(Long id);
    public ProfessionalExperience save(ProfessionalExperience ProfessionalExperience);
    public void deleteById(Long id);
}
