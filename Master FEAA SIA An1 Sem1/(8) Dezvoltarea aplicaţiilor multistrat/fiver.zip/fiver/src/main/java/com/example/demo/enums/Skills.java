package com.example.demo.enums;

public enum Skills {
    Communication,Teamwork,ProblemSolving,Adaptability,Creativity,TimeManagement
}
