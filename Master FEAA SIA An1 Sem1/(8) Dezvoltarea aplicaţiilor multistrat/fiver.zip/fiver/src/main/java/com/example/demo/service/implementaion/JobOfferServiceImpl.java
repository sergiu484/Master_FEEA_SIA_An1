package com.example.demo.service.implementaion;

import com.example.demo.dao.JobOfferDao;
import com.example.demo.entities.ApplicationUser;
import com.example.demo.entities.JobOffer;
import com.example.demo.service.JobOfferService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class JobOfferServiceImpl implements JobOfferService {
    private  final JobOfferDao jobOfferDao;


    public JobOfferServiceImpl(JobOfferDao jobOfferDao) {
        this.jobOfferDao = jobOfferDao;
    }

    @Override
    public List<JobOffer> findAll() {
        return jobOfferDao.findAll();
    }

    @Override
    public Optional<JobOffer> findById(Long id) {
        return jobOfferDao.findById(id);
    }

    @Override
    public JobOffer save(JobOffer jobOffer) {
        return jobOfferDao.save(jobOffer);
    }

    @Override
    public void deleteById(Long id) {
        jobOfferDao.delete(id);
    }
}
