package com.example.demo.service;

import com.example.demo.entities.ComputerKnowledge;

import java.util.List;
import java.util.Optional;

public interface ComputerKnowledgeService {
    public List<ComputerKnowledge> findAll();
    public Optional<ComputerKnowledge> findById(Long id);
    public ComputerKnowledge save(ComputerKnowledge ComputerKnowledge);
    public void deleteById(Long id);
}
