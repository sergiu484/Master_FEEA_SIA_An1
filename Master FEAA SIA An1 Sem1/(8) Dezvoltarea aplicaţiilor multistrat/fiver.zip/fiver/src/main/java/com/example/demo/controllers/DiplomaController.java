package com.example.demo.controllers;

import com.example.demo.dto.DiplomaDto;
import com.example.demo.mappers.DiplomaMapper;
import com.example.demo.service.DiplomaService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("diplomas")
public class DiplomaController {

    private final  DiplomaService DiplomaService;
    private final DiplomaMapper DiplomaMapper;
    private final DiplomaDto DiplomaDTO;

    public DiplomaController(DiplomaDto DiplomaDTO, DiplomaService DiplomaService, DiplomaMapper DiplomaMapper) {
        this.DiplomaDTO = DiplomaDTO;
        this.DiplomaService = DiplomaService;
        this.DiplomaMapper = DiplomaMapper;
    }


    @GetMapping
    public ResponseEntity<List<DiplomaDto>> getAllDiplomas() {
        return ResponseEntity.ok(DiplomaMapper.convertToDtos(DiplomaService.findAll()));
    }

    @Operation(description = "Add new   Diploma")
    @ApiResponses(value = {@ApiResponse(responseCode = "201", description = "  Diploma aded",
            content = @Content),
            @ApiResponse(responseCode = "400", description = "Invalid   Diploma    data",
                    content = @Content),
            @ApiResponse(responseCode = "500", description = "Business exception",
                    content = @Content)})

    @PostMapping
    public ResponseEntity<DiplomaDto> addDiploma(@RequestBody DiplomaDto DiplomaDto) {
        DiplomaService.save(DiplomaMapper.convertToEntity(DiplomaDto));
        return ResponseEntity.status(HttpStatus.CREATED).body(DiplomaDto);

    }

    @Operation(description = "Delete a   Diploma")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "204", description = "  Diploma deleted",
                    content = @Content),
            @ApiResponse(responseCode = "404", description = "  Diploma not found to update",
                    content = @Content)})

    @DeleteMapping("{id Diploma}")
    public void cancelTrip(@PathVariable Long idDiploma) {
        this.DiplomaService.deleteById(idDiploma);

    }
}
