package com.example.demo.dao;
import com.example.demo.entities.ApplicationUser;
import com.example.demo.repositories.ApplicationUserRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

import java.util.Optional;

@Repository
public class ApplicationUserDao {

    private final ApplicationUserRepository applicationUserRepository;



    public ApplicationUserDao(ApplicationUserRepository applicationUserRepository) {
        this.applicationUserRepository = applicationUserRepository;
    }

    public List<ApplicationUser> findAll() {

        return applicationUserRepository.findAll();
    }

    public Optional<ApplicationUser> findById(Long id) {

       return applicationUserRepository.findById(id);
    }

    public ApplicationUser save (ApplicationUser applicationUser) {

  return applicationUserRepository.save(applicationUser);

    }


    public void delete(Long id) {

         applicationUserRepository.delete(applicationUserRepository.getOne(id));
    }


}
