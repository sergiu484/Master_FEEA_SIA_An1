package com.example.demo.mappers;

import com.example.demo.dto.ComputerKnowledgeDto;
import com.example.demo.entities.ComputerKnowledge;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

import java.util.List;

@Component

public class ComputerKnowledgeMapper {
    private final ModelMapper modelMapper;

    public ComputerKnowledgeMapper(ModelMapper modelMapper) {
        this.modelMapper = modelMapper;
    }

    public ComputerKnowledgeDto convertToDto(ComputerKnowledge ComputerKnowledge) {
        return modelMapper.map(ComputerKnowledge, ComputerKnowledgeDto.class);
    }
    public List<ComputerKnowledgeDto> convertToDtos(List<ComputerKnowledge> cars) {
        return modelMapper.map(cars, List.class);
    }
    public ComputerKnowledge convertToEntity(ComputerKnowledgeDto dto) {
        return modelMapper.map(dto, ComputerKnowledge.class);
    }
    public ComputerKnowledge convertToNewEntity(ComputerKnowledgeDto ComputerKnowledgeDto) {
        ComputerKnowledge  ComputerKnowledge =  modelMapper.map(ComputerKnowledgeDto, ComputerKnowledge.class);

        return ComputerKnowledge;
    }

}
