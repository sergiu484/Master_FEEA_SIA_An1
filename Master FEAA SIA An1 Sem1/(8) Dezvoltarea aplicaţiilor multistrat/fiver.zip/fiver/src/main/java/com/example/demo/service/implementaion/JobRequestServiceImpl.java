package com.example.demo.service.implementaion;

import com.example.demo.dao. JobRequestDao;
import com.example.demo.entities. JobRequest;
import com.example.demo.service.JobRequestService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class JobRequestServiceImpl implements JobRequestService {
    private  final  JobRequestDao  JobRequestDao;


    public  JobRequestServiceImpl( JobRequestDao  JobRequestDao) {
        this. JobRequestDao =  JobRequestDao;
    }

    @Override
    public List< JobRequest> findAll() {
        return  JobRequestDao.findAll();
    }

    @Override
    public Optional< JobRequest> findById(Long id) {
        return  JobRequestDao.findById(id);
    }

    @Override
    public  JobRequest save( JobRequest  JobRequest) {
        return  JobRequestDao.save( JobRequest);
    }

    @Override
    public void deleteById(Long id) {
         JobRequestDao.delete(id);
    }
}
