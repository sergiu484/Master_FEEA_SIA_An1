package com.example.demo.enums;

public enum ProgrammingLanguage {
    Python,HTML,Java,ObjectiveC, PHP,SQL,Swift;
}
