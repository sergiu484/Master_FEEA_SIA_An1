package com.example.demo.dao;
import com.example.demo.entities.JobRequest;
import com.example.demo.repositories.JobRequestRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class JobRequestDao {
    private final JobRequestRepository jobRequestRepository;


    public JobRequestDao(JobRequestRepository jobRequestRepository) {
        this.jobRequestRepository = jobRequestRepository;
    }

    public List<JobRequest> findAll() {

        return jobRequestRepository.findAll();
    }

    public Optional<JobRequest> findById(Long id) {

        return jobRequestRepository.findById(id);
    }

    public JobRequest save(JobRequest jobRequest) {

        return jobRequestRepository.save(jobRequest);

    }


    public void delete(Long id) {

        jobRequestRepository.delete(jobRequestRepository.getOne(id));
    }
}
