package com.example.demo.controllers;

import com.example.demo.dto.ProfessionalExperienceDto;
import com.example.demo.mappers.ProfessionalExperienceMapper;
import com.example.demo.service.ProfessionalExperienceService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("professionalExperiences")
public class ProfessionalExperienceController {
    private final ProfessionalExperienceService ProfessionalExperienceService;
    private final  ProfessionalExperienceMapper ProfessionalExperienceMapper;
    private final ProfessionalExperienceDto ProfessionalExperienceDTO;

    public ProfessionalExperienceController(ProfessionalExperienceDto ProfessionalExperienceDTO, ProfessionalExperienceService ProfessionalExperienceService, ProfessionalExperienceMapper ProfessionalExperienceMapper) {
        this.ProfessionalExperienceDTO = ProfessionalExperienceDTO;
        this.ProfessionalExperienceService = ProfessionalExperienceService;
        this.ProfessionalExperienceMapper = ProfessionalExperienceMapper;
    }


    @GetMapping
    public ResponseEntity<List<ProfessionalExperienceDto>> getAllProfessionalExperiences() {
        return ResponseEntity.ok(ProfessionalExperienceMapper.convertToDtos(ProfessionalExperienceService.findAll()));
    }

    @Operation(description = "Add new   ProfessionalExperience")
    @ApiResponses(value = {@ApiResponse(responseCode = "201", description = "  ProfessionalExperience aded",
            content = @Content),
            @ApiResponse(responseCode = "400", description = "Invalid   ProfessionalExperience    data",
                    content = @Content),
            @ApiResponse(responseCode = "500", description = "Business exception",
                    content = @Content)})

    @PostMapping
    public ResponseEntity<ProfessionalExperienceDto> addProfessionalExperience(@RequestBody ProfessionalExperienceDto ProfessionalExperienceDto) {
        ProfessionalExperienceService.save(ProfessionalExperienceMapper.convertToEntity(ProfessionalExperienceDto));
        return ResponseEntity.status(HttpStatus.CREATED).body(ProfessionalExperienceDto);

    }

    @Operation(description = "Delete a   ProfessionalExperience")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "204", description = "  ProfessionalExperience deleted",
                    content = @Content),
            @ApiResponse(responseCode = "404", description = "  ProfessionalExperience not found to update",
                    content = @Content)})

    @DeleteMapping("{id ProfessionalExperience}")
    public void cancelTrip(@PathVariable Long idProfessionalExperience) {
        this.ProfessionalExperienceService.deleteById(idProfessionalExperience);

    }
}
