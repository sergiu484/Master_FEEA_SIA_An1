package com.example.demo.dao;
import com.example.demo.entities.ProfessionalExperience;
import com.example.demo.repositories.ProfessionalExperienceRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class ProfessionalExperienceDao {
    private final ProfessionalExperienceRepository professionalExperienceRepository;


    public ProfessionalExperienceDao(ProfessionalExperienceRepository professionalExperienceRepository) {
        this.professionalExperienceRepository = professionalExperienceRepository;
    }

    public List<ProfessionalExperience> findAll() {

        return professionalExperienceRepository.findAll();
    }

    public Optional<ProfessionalExperience> findById(Long id) {

        return professionalExperienceRepository.findById(id);
    }

    public ProfessionalExperience save(ProfessionalExperience professionalExperience) {

        return professionalExperienceRepository.save(professionalExperience);

    }


    public void delete(Long id) {

        professionalExperienceRepository.delete(professionalExperienceRepository.getOne(id));
    }
}
