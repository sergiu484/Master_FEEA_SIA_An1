package com.example.demo.enums;

public enum CandidateType {
    HR;
}
