package com.example.demo.dao;

import com.example.demo.entities.JobRequest;
import com.example.demo.entities.LinguisticKnowledge;
import com.example.demo.repositories.JobRequestRepository;
import com.example.demo.repositories.LinguisticKnowledgeRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class LinguisticKnowledgeDao {
    private final LinguisticKnowledgeRepository linguisticKnowledgeRepository;


    public LinguisticKnowledgeDao(LinguisticKnowledgeRepository linguisticKnowledgeRepository) {
        this.linguisticKnowledgeRepository = linguisticKnowledgeRepository;
    }

    public List<LinguisticKnowledge> findAll() {

        return linguisticKnowledgeRepository.findAll();
    }

    public Optional<LinguisticKnowledge> findById(Long id) {

        return linguisticKnowledgeRepository.findById(id);
    }

    public LinguisticKnowledge save(LinguisticKnowledge linguisticKnowledge) {

        return linguisticKnowledgeRepository.save(linguisticKnowledge);

    }


    public void delete(Long id) {

        linguisticKnowledgeRepository.delete(linguisticKnowledgeRepository.getOne(id));
    }
}
