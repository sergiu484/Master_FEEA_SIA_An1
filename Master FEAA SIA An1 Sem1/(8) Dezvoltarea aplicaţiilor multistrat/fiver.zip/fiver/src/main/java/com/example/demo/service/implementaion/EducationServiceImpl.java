package com.example.demo.service.implementaion;

import com.example.demo.dao. EducationDao;
import com.example.demo.entities. Education;
import com.example.demo.service.EducationService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EducationServiceImpl implements EducationService {
    private  final  EducationDao  EducationDao;

    public  EducationServiceImpl( EducationDao  EducationDao) {
        this. EducationDao =  EducationDao;
    }

    @Override
    public List< Education> findAll() {
        return  EducationDao.findAll();
    }

    @Override
    public Optional< Education> findById(Long id) {
        return  EducationDao.findById(id);
    }

    @Override
    public  Education save( Education  Education) {
        return  EducationDao.save( Education);
    }

    @Override
    public void deleteById(Long id) {
         EducationDao.delete(id);
    }
}
