package com.example.demo.entities;

import com.example.demo.enums.RecuiterPost;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.List;


@Entity
@Inheritance(strategy = InheritanceType.JOINED)
@Data @AllArgsConstructor @NoArgsConstructor
@PrimaryKeyJoinColumn(name = "id")

public class Recruiter extends ApplicationUser{
    @Enumerated
    private RecuiterPost recuiterPost;
    @ManyToMany
    private List<JobOffer> jobOffers;
    @ManyToMany
    private List<JobRequest > jobRequests;

}
