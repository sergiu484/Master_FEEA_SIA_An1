package com.example.demo.mappers;

import com.example.demo.dto.DiplomaDto;
import com.example.demo.entities.Diploma;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

import java.util.List;

@Component

public class DiplomaMapper {
    private final ModelMapper modelMapper;

    public DiplomaMapper(ModelMapper modelMapper) {
        this.modelMapper = modelMapper;
    }

    public DiplomaDto convertToDto(Diploma Diploma) {
        return modelMapper.map(Diploma, DiplomaDto.class);
    }
    public List<DiplomaDto> convertToDtos(List<Diploma> cars) {
        return modelMapper.map(cars, List.class);
    }
    public Diploma convertToEntity(DiplomaDto dto) {
        return modelMapper.map(dto, Diploma.class);
    }
    public Diploma convertToNewEntity(DiplomaDto DiplomaDto) {
        Diploma  Diploma =  modelMapper.map(DiplomaDto, Diploma.class);

        return Diploma;
    }

}
