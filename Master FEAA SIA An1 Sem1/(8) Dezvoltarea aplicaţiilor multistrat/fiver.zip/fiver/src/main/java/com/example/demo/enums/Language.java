package com.example.demo.enums;

public enum Language {
    English,Spanish,French,German,
}
