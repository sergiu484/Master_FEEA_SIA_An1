package com.example.demo.service;

import com.example.demo.entities.Education;

import java.util.List;
import java.util.Optional;

public interface EducationService {
    public List<Education> findAll();
    public Optional<Education> findById(Long id);
    public Education save(Education Education);
    public void deleteById(Long id);
}
