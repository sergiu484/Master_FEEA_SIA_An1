package com.example.demo.service.implementaion;
import com.example.demo.dao.ApplicationUserDao;
import com.example.demo.entities.ApplicationUser;
import com.example.demo.service.ApplicationUserService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;


@Service

public class ApplicationUserServiceImpl implements ApplicationUserService {

    private  final ApplicationUserDao applicationUserDao;

    public ApplicationUserServiceImpl(ApplicationUserDao applicationUserDao) {
        this.applicationUserDao = applicationUserDao;
    }

    @Override
    public List<ApplicationUser> findAll() {
        return applicationUserDao.findAll();
    }

    @Override
    public Optional<ApplicationUser> findById(Long id) {
        return applicationUserDao.findById(id);
    }

    @Override
    public ApplicationUser save(ApplicationUser ApplicationUser) {
        return applicationUserDao.save(ApplicationUser);
    }

    @Override
    public void deleteById(Long id) {
        applicationUserDao.delete(id);
    }
}
