package com.example.demo.service;

import com.example.demo.entities.Candidate;

import java.util.List;
import java.util.Optional;

public interface CandidateService {
    public List<Candidate> findAll();
    public Optional<Candidate> findById(Long id);
    public Candidate save(Candidate Candidate);
    public void deleteById(Long id);
    
}
