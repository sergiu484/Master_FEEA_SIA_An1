package com.example.demo.dto;

import com.example.demo.enums.RecuiterPost;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Enumerated;
import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor

public class RecruiterDto implements Serializable {
    private static final long serialVersionUID = 1L;

    private RecuiterPost recuiterPost;

}
