package com.example.demo.mappers;

import com.example.demo.dto.LinguisticKnowledgeDto;
import com.example.demo.entities.LinguisticKnowledge;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

import java.util.List;

@Component

public class LinguisticKnowledgeMappper {
    private final ModelMapper modelMapper;

    public LinguisticKnowledgeMappper(ModelMapper modelMapper) {
        this.modelMapper = modelMapper;
    }

    public LinguisticKnowledgeDto convertToDto(LinguisticKnowledge LinguisticKnowledge) {
        return modelMapper.map(LinguisticKnowledge, LinguisticKnowledgeDto.class);
    }
    public List<LinguisticKnowledgeDto> convertToDtos(List<LinguisticKnowledge> cars) {
        return modelMapper.map(cars, List.class);
    }
    public LinguisticKnowledge convertToEntity(LinguisticKnowledgeDto dto) {
        return modelMapper.map(dto, LinguisticKnowledge.class);
    }
    public LinguisticKnowledge convertToNewEntity(LinguisticKnowledgeDto LinguisticKnowledgeDto) {
        LinguisticKnowledge  LinguisticKnowledge =  modelMapper.map(LinguisticKnowledgeDto, LinguisticKnowledge.class);

        return LinguisticKnowledge;
    }

}
