package com.example.demo.dto;

import com.example.demo.enums.ProgrammingLanguage;
import com.example.demo.enums.Se;
import com.example.demo.enums.Software;
import lombok.*;

import javax.persistence.Enumerated;
import java.io.Serializable;
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor


public class ComputerKnowledgeDto implements Serializable {
    private static final long serialVersionUID = 1L;
    private Long id;
     private Software software;
     private ProgrammingLanguage programmingLanguage;
     private Se se;

}
