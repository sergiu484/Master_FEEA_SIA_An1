package com.example.demo.controllers;

import com.example.demo.dto.JobOfferDto;
import com.example.demo.mappers.JobOfferMapper;
import com.example.demo.service.JobOfferService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("jobOffers")
public class JobOfferController {
    private final  JobOfferService JobOfferService;
    private final  JobOfferMapper JobOfferMapper;
    private final JobOfferDto JobOfferDTO;

    public JobOfferController(JobOfferDto JobOfferDTO, JobOfferService JobOfferService, JobOfferMapper JobOfferMapper) {
        this.JobOfferDTO = JobOfferDTO;
        this.JobOfferService = JobOfferService;
        this.JobOfferMapper = JobOfferMapper;
    }


    @GetMapping
    public ResponseEntity<List<JobOfferDto>> getAllJobOffers() {
        return ResponseEntity.ok(JobOfferMapper.convertToDtos(JobOfferService.findAll()));
    }

    @Operation(description = "Add new   JobOffer")
    @ApiResponses(value = {@ApiResponse(responseCode = "201", description = "  JobOffer aded",
            content = @Content),
            @ApiResponse(responseCode = "400", description = "Invalid   JobOffer    data",
                    content = @Content),
            @ApiResponse(responseCode = "500", description = "Business exception",
                    content = @Content)})

    @PostMapping
    public ResponseEntity<JobOfferDto> addJobOffer(@RequestBody JobOfferDto JobOfferDto) {
        JobOfferService.save(JobOfferMapper.convertToEntity(JobOfferDto));
        return ResponseEntity.status(HttpStatus.CREATED).body(JobOfferDto);

    }

    @Operation(description = "Delete a   JobOffer")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "204", description = "  JobOffer deleted",
                    content = @Content),
            @ApiResponse(responseCode = "404", description = "  JobOffer not found to update",
                    content = @Content)})

    @DeleteMapping("{id JobOffer}")
    public void cancelTrip(@PathVariable Long idJobOffer) {
        this.JobOfferService.deleteById(idJobOffer);

    }
}
