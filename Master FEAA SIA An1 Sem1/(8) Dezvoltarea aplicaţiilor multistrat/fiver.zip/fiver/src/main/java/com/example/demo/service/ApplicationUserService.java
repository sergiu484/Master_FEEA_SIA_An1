package com.example.demo.service;

import com.example.demo.entities.ApplicationUser;

import java.util.List;
import java.util.Optional;

public interface ApplicationUserService {
    public List<ApplicationUser> findAll();
    public Optional<ApplicationUser> findById(Long id);
    public ApplicationUser save(ApplicationUser ApplicationUser);
    public void deleteById(Long id);

}
