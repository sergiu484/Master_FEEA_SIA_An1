package com.example.demo.entities;

import com.example.demo.enums.ProgrammingLanguage;
import com.example.demo.enums.Se;
import com.example.demo.enums.Software;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.List;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class ComputerKnowledge {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    @Enumerated
    private Software software;
    @Enumerated
    private ProgrammingLanguage programmingLanguage;
    @Enumerated
    private Se se;

    @ManyToMany
    private List<JobOffer> jobOffers;
    @ManyToMany
    private List<JobRequest> jobRequests;
}
