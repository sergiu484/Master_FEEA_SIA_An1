package com.example.demo.dto;

import com.example.demo.entities.JobRequest;
import com.example.demo.enums.CandidateType;
import com.example.demo.enums.Skills;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Enumerated;
import java.io.Serializable;
import java.util.Date;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor

public class ProfessionalExperienceDto implements Serializable {
    private static final long serialVersionUID = 1L;
    private List<JobRequest> jobRequests;
    private String nameCompany;

    private CandidateType positionOccupied;
    private String region;
    private Date startOfWork;
    private Date endOfWork;

    private Skills skill;

}
