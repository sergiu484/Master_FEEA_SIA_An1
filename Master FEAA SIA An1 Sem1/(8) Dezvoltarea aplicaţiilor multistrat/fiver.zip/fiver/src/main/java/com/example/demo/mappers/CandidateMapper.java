package com.example.demo.mappers;

import com.example.demo.dto.CandidateDto;
import com.example.demo.entities.Candidate;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

import java.util.List;

@Component

public class CandidateMapper {
    private final ModelMapper modelMapper;

    public CandidateMapper(ModelMapper modelMapper) {
        this.modelMapper = modelMapper;
    }

    public CandidateDto convertToDto(Candidate Candidate) {
        return modelMapper.map(Candidate, CandidateDto.class);
    }
    public List<CandidateDto> convertToDtos(List<Candidate> cars) {
        return modelMapper.map(cars, List.class);
    }
    public Candidate convertToEntity(CandidateDto dto) {
        return modelMapper.map(dto, Candidate.class);
    }
    public Candidate convertToNewEntity(CandidateDto CandidateDto) {
        Candidate  Candidate =  modelMapper.map(CandidateDto, Candidate.class);

        return Candidate;
    }

}
