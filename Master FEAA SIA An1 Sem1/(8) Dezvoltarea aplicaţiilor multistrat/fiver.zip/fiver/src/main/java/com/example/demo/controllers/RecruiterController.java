package com.example.demo.controllers;

import com.example.demo.dto.RecruiterDto;
import com.example.demo.mappers.RecruiterMapper;
import com.example.demo.service.RecruiterService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("recruiter")
public class RecruiterController {
    private final RecruiterService RecruiterService;
    private final  RecruiterMapper RecruiterMapper;
    private final RecruiterDto RecruiterDTO;

    public RecruiterController(RecruiterDto RecruiterDTO, RecruiterService RecruiterService, RecruiterMapper RecruiterMapper) {
        this.RecruiterDTO = RecruiterDTO;
        this.RecruiterService = RecruiterService;
        this.RecruiterMapper = RecruiterMapper;
    }


    @GetMapping
    public ResponseEntity<List<RecruiterDto>> getAllRecruiters() {
        return ResponseEntity.ok(RecruiterMapper.convertToDtos(RecruiterService.findAll()));
    }

    @Operation(description = "Add new   Recruiter")
    @ApiResponses(value = {@ApiResponse(responseCode = "201", description = "  Recruiter aded",
            content = @Content),
            @ApiResponse(responseCode = "400", description = "Invalid   Recruiter    data",
                    content = @Content),
            @ApiResponse(responseCode = "500", description = "Business exception",
                    content = @Content)})

    @PostMapping
    public ResponseEntity<RecruiterDto> addRecruiter(@RequestBody RecruiterDto RecruiterDto) {
        RecruiterService.save(RecruiterMapper.convertToEntity(RecruiterDto));
        return ResponseEntity.status(HttpStatus.CREATED).body(RecruiterDto);

    }

    @Operation(description = "Delete a   Recruiter")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "204", description = "  Recruiter deleted",
                    content = @Content),
            @ApiResponse(responseCode = "404", description = "  Recruiter not found to update",
                    content = @Content)})

    @DeleteMapping("{id Recruiter}")
    public void cancelTrip(@PathVariable Long idRecruiter) {
        this.RecruiterService.deleteById(idRecruiter);

    }
}
