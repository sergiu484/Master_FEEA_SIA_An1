package com.example.demo.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.Date;
import java.util.List;
    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Entity
    public class JobRequest {
        @Id
        @GeneratedValue(strategy = GenerationType.AUTO)
        private Long id;
        private Date date;
        @ManyToMany
        private List<ProfessionalExperience> professionalExperiences;
        @ManyToMany
        private List<LinguisticKnowledge> linguisticKnowledges;
        @ManyToMany
        private List<ComputerKnowledge> computerKnowledges;
        @OneToOne
        private Diploma diploma;

        @ManyToMany
        private List<Candidate> candidates;
        @ManyToMany
        private List<Recruiter> recruiters;
}
