package com.example.demo.dao;
import com.example.demo.entities.Candidate;
import com.example.demo.repositories.CandidateRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class CandidateDao {
    private final CandidateRepository candidateRepository;



    public CandidateDao(CandidateRepository candidateRepository) {
        this.candidateRepository = candidateRepository;
    }

    public List<Candidate> findAll() {

        return candidateRepository.findAll();
    }

    public Optional<Candidate> findById(Long id) {

        return candidateRepository.findById(id);
    }

    public Candidate save (Candidate candidate) {

        return candidateRepository.save(candidate);

    }


    public void delete(Long id) {

        candidateRepository.delete(candidateRepository.getOne(id));
    }


}
