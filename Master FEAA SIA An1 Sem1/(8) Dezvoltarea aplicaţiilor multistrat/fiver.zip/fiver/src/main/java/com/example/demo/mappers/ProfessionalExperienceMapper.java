package com.example.demo.mappers;

import com.example.demo.dto.ProfessionalExperienceDto;
import com.example.demo.entities.ProfessionalExperience;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

import java.util.List;

@Component

public class ProfessionalExperienceMapper {
    private final ModelMapper modelMapper;

    public ProfessionalExperienceMapper(ModelMapper modelMapper) {
        this.modelMapper = modelMapper;
    }

    public ProfessionalExperienceDto convertToDto(ProfessionalExperience ProfessionalExperience) {
        return modelMapper.map(ProfessionalExperience, ProfessionalExperienceDto.class);
    }
    public List<ProfessionalExperienceDto> convertToDtos(List<ProfessionalExperience> cars) {
        return modelMapper.map(cars, List.class);
    }
    public ProfessionalExperience convertToEntity(ProfessionalExperienceDto dto) {
        return modelMapper.map(dto, ProfessionalExperience.class);
    }
    public ProfessionalExperience convertToNewEntity(ProfessionalExperienceDto ProfessionalExperienceDto) {
        ProfessionalExperience  ProfessionalExperience =  modelMapper.map(ProfessionalExperienceDto, ProfessionalExperience.class);

        return ProfessionalExperience;
    }

}
