package com.example.demo.service;



import com.example.demo.entities.Diploma;

import java.util.List;
import java.util.Optional;

public interface DiplomaService {
    public List<Diploma> findAll();
    public Optional<Diploma> findById(Long id);
    public Diploma save(Diploma diploma);
    public void deleteById(Long id);
}
