package com.example.demo.controllers;

 import com.example.demo.dto.LinguisticKnowledgeDto;
 import com.example.demo.mappers.LinguisticKnowledgeMappper;
 import com.example.demo.service.LinguisticKnowledgeService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("linguisticKnowledges")
public class LinguisticKnowledgeController {
    private final LinguisticKnowledgeService LinguisticKnowledgeCService;
    private final LinguisticKnowledgeMappper LinguisticKnowledgeCMapper;
    private final LinguisticKnowledgeDto LinguisticKnowledgeCDTO;

    public LinguisticKnowledgeController(LinguisticKnowledgeService linguisticKnowledgeCService, LinguisticKnowledgeMappper linguisticKnowledgeCMapper, LinguisticKnowledgeDto linguisticKnowledgeCDTO) {
        LinguisticKnowledgeCService = linguisticKnowledgeCService;
        LinguisticKnowledgeCMapper = linguisticKnowledgeCMapper;
        LinguisticKnowledgeCDTO = linguisticKnowledgeCDTO;
    }


    @GetMapping
    public ResponseEntity<List<LinguisticKnowledgeDto>> getAllLinguisticKnowledgeCs() {
        return ResponseEntity.ok(LinguisticKnowledgeCMapper.convertToDtos(LinguisticKnowledgeCService.findAll()));
    }

    @Operation(description = "Add new   LinguisticKnowledgeC")
    @ApiResponses(value = {@ApiResponse(responseCode = "201", description = "  LinguisticKnowledgeC aded",
            content = @Content),
            @ApiResponse(responseCode = "400", description = "Invalid   LinguisticKnowledgeC    data",
                    content = @Content),
            @ApiResponse(responseCode = "500", description = "Business exception",
                    content = @Content)})

    @PostMapping
    public ResponseEntity<LinguisticKnowledgeDto> addLinguisticKnowledgeC(@RequestBody LinguisticKnowledgeDto LinguisticKnowledgeCDto) {
        LinguisticKnowledgeCService.save(LinguisticKnowledgeCMapper.convertToEntity(LinguisticKnowledgeCDto));
        return ResponseEntity.status(HttpStatus.CREATED).body(LinguisticKnowledgeCDto);

    }

    @Operation(description = "Delete a   LinguisticKnowledgeC")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "204", description = "  LinguisticKnowledgeC deleted",
                    content = @Content),
            @ApiResponse(responseCode = "404", description = "  LinguisticKnowledgeC not found to update",
                    content = @Content)})

    @DeleteMapping("{id LinguisticKnowledgeC}")
    public void cancelTrip(@PathVariable Long idLinguisticKnowledgeC) {
        this.LinguisticKnowledgeCService.deleteById(idLinguisticKnowledgeC);

    }
}
