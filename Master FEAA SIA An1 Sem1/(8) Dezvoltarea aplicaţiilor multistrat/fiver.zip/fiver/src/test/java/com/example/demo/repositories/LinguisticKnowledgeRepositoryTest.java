package com.example.demo.repositories;

import com.example.demo.entities.ApplicationUser;
import com.example.demo.entities.LinguisticKnowledge;
import com.example.demo.entities.LinguisticKnowledge;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@DataJpaTest
public class LinguisticKnowledgeRepositoryTest {
    @Autowired
    LinguisticKnowledgeRepository LinguisticKnowledgeRepository;

    @Test
    public void testRepository()
    {
        LinguisticKnowledge LinguisticKnowledge = new LinguisticKnowledge();
        LinguisticKnowledge.setId(2L);

        LinguisticKnowledgeRepository.save(LinguisticKnowledge);

        Assert.assertNotNull(LinguisticKnowledge.getId());
    }
}
