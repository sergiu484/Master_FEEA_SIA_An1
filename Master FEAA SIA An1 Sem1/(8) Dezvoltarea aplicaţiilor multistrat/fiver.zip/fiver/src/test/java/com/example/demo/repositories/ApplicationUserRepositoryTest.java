package com.example.demo.repositories;

import com.example.demo.entities.ApplicationUser;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@DataJpaTest
public class ApplicationUserRepositoryTest {
    @Autowired
    ApplicationUserRepository applicationUserRepository;

    @Test
    public void testRepository()
    {
        ApplicationUser applicationUser = new ApplicationUser();
        applicationUser.setFirstName("ons");

        applicationUserRepository.save(applicationUser);

        Assert.assertNotNull(applicationUser.getId());
    }

}
