package com.example.demo.repositories;

import com.example.demo.entities.ApplicationUser;
import com.example.demo.entities.ComputerKnowledge;
import com.example.demo.entities.ComputerKnowledge;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@DataJpaTest
public class ComputerKnowledgeRepositoryTest  {
    @Autowired
    ComputerKnowledgeRepository ComputerKnowledgeRepository;

    @Test
    public void testRepository()
    {
        ComputerKnowledge ComputerKnowledge = new ComputerKnowledge();
        ComputerKnowledge.setId(2L);

        ComputerKnowledgeRepository.save(ComputerKnowledge);

        Assert.assertNotNull(ComputerKnowledge.getId());
    }
}
