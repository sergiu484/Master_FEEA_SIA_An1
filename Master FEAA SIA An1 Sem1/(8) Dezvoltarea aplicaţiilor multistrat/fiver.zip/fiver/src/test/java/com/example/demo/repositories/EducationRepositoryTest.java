package com.example.demo.repositories;

import com.example.demo.entities.ApplicationUser;
import com.example.demo.entities.Education;
import com.example.demo.entities.Education;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@DataJpaTest
public class EducationRepositoryTest {
    @Autowired
    EducationRepository EducationRepository;

    @Test
    public void testRepository()
    {
        Education Education = new Education();
        Education.setId(2L);

        EducationRepository.save(Education);

        Assert.assertNotNull(Education.getId());
    }
}
