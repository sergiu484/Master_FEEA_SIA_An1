package com.example.demo.repositories;

import com.example.demo.entities.ApplicationUser;
import com.example.demo.entities.Diploma;
import com.example.demo.entities.Diploma;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@DataJpaTest
public class DiplomaRepositoryTest {
    @Autowired
    DiplomaRepository DiplomaRepository;

    @Test
    public void testRepository()
    {
        Diploma Diploma = new Diploma();
        Diploma.setId(2L);

        DiplomaRepository.save(Diploma);

        Assert.assertNotNull(Diploma.getId());
    }
}
