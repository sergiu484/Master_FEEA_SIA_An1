package com.example.demo.repositories;

import com.example.demo.entities.ApplicationUser;
import com.example.demo.entities.Recruiter;
import com.example.demo.entities.Recruiter;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@DataJpaTest
public class RecruiterRepositoryTest   {
    @Autowired
    RecruiterRepository RecruiterRepository;

    @Test
    public void testRepository()
    {
        Recruiter Recruiter = new Recruiter();
        Recruiter.setId(2L);

        RecruiterRepository.save(Recruiter);

        Assert.assertNotNull(Recruiter.getId());
    }
}
